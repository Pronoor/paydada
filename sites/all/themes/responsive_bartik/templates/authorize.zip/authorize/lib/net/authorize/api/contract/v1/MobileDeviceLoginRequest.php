<?php

namespace net\authorize\api\contract\v1;

/**
 * Class representing MobileDeviceLoginRequest
 */
class MobileDeviceLoginRequest extends ANetApiRequestType
{


}

